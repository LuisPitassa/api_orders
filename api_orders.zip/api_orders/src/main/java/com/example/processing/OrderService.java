package com.example.service;

import com.example.model.*;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDateTime;
import java.util.List;
import java.util.logging.Logger;

@Stateless
public class OrderService {

    //serviço para processar a order
    //vai ser usado o logger para fins de logging

    @PersistenceContext
    private EntityManager entity;

    @Inject
    private EmailService emailService;

    private static final Logger logger = Logger.getLogger(OrderService.class.getName());

    //função para criar a order. vai entrar na completeOrder para verificar se a ordem foi completa.
    public void createOrder(Order order) {
        order.setCreationDate(LocalDateTime.now());
        order.setCompleteQuantity(0);
        order.setCompleted(false);
        completeOrder(order);
        entity.persist(order);
    }

    public void completeOrder(Order order) {

        //vai verificar se nos stocks, existe o item e se existe quantidade.
        List<StockMovement> stock = entity.createQuery(
            "SELECT s FROM StockMovement s WHERE s.item = :item AND s.quantity > 0", StockMovement.class)
            .setParameter("item", order.getItem())
            .getResultList();

        //vai verificar a quantidade da order. verifica o mínimo entre a quantidade em stock e a quantidade precisa para a order.
        //vai preencher a variável de auxílio com o mínimo que foi inserido.
        int needed = order.getQuantity() - order.getCompleteQuantity();
        for (StockMovement smovement : stock) {
            if (needed <= 0) break;
            int use = Math.min(smovement.getQuantity(), needed);
            smovement.setQuantity(smovement.getQuantity() - use);
            needed -= use;
            order.getStockMovements().add(smovement);
            order.setCompleteQuantity(order.getCompleteQuantity() + use);
            entity.merge(smovement);
        }

        //vai verificar se a variável de auxílio é igual ou maior que a quantidade inserida.
        //caso positivo, a order será metida como completa, e enviará um email ao user.
        if (order.getCompleteQuantity() >= order.getQuantity()) {
            order.setCompleted(true);
            emailService.sendOrderCompletedEmail(order.getUser(), order);
            logger.info("Order #" + order.getId() + " completed.");
        }

        entity.merge(order);
    }
}