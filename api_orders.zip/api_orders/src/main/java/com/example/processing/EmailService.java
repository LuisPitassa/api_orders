package com.example.service;

import com.example.model.Order;
import com.example.model.User;

import javax.ejb.Stateless;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

@Stateless
public class EmailService {
    public void sendOrderCompletedEmail(User user, Order order) {

        //usando o javax.mail, vamos usar o envio simples de smtp
        //vai colocar o from default, e vai usar o to como o user da order, e vai buscar no body, o nome do user e o id da order.
		
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.yourserver.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getDefaultInstance(props);
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress("no-reply@order.com"));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
            msg.setSubject("Order Completed");
            msg.setText("Hello " + user.getName() + ", your order #" + order.getId() + " is completed.");

            Transport.send(msg);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}