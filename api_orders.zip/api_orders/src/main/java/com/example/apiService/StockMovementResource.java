package com.example.rest;

import com.example.model.StockMovement;
import com.example.model.Order;
import com.example.service.OrderService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.time.LocalDateTime;
import java.util.List;

@Path("/stock-movements")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Transactional
public class StockMovementResource {

    //serviço para a api referente aos movimentos de stock. vai conter o criar, o get, e o listar todos.

    @PersistenceContext
    private EntityManager entity;

    @Inject
    private OrderService orderService;

    //o criar vai verificar se existem orders pendentes, para realizar a acção
    @POST
    public StockMovement createStockMovement(StockMovement stockMovement) {
        stockMovement.setCreationDate(LocalDateTime.now());
        entity.persist(stockMovement);

        List<Order> pendingOrders = entity.createQuery(
            "SELECT o FROM Order o WHERE o.item = :item AND o.completed = false", Order.class)
            .setParameter("item", stockMovement.getItem())
            .getResultList();

        for (Order order : pendingOrders) {
            orderService.completeOrder(order);
        }

        return stockMovement;
    }

    @GET
    public List<StockMovement> getAllStockMovements() {
        return entity.createQuery("SELECT s FROM StockMovement s", StockMovement.class).getResultList();
    }

    @GET
    @Path("/{id}")
    public StockMovement getStockMovement(@PathParam("id") Long id) {
        return entity.find(StockMovement.class, id);
    }
}