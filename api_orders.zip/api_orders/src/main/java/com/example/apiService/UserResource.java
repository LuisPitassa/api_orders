package com.example.rest;

import com.example.model.User;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Transactional
public class UserResource {

    //serviço para a api referente aos users. vai conter o criar, o get, e o listar todos.

    @PersistenceContext
    private EntityManager entity;

    @POST
    public User createUser(User user) {
        entity.persist(user);
        return user;
    }

    @GET
    public List<User> getAllUsers() {
        return entity.createQuery("SELECT u FROM User u", User.class).getResultList();
    }

    @GET
    @Path("/{id}")
    public User getUser(@PathParam("id") Long id) {
        return entity.find(User.class, id);
    }
}