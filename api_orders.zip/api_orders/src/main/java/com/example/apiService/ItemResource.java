package com.example.rest;

import com.example.model.Item;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/items")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Transactional
public class ItemResource {

    //serviço para a api referente aos items. vai conter o criar, o get, e o listar todos.

    @PersistenceContext
    private EntityManager entity;

    @POST
    public Item createItem(Item item) {
        entity.persist(item);
        return item;
    }

    @GET
    public List<Item> getAllItems() {
        return entity.createQuery("SELECT i FROM Item i", Item.class).getResultList();
    }

    @GET
    @Path("/{id}")
    public Item getItem(@PathParam("id") Long id) {
        return entity.find(Item.class, id);
    }
}