package com.example.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "orders")
public class Order {

    //entidade orders que contém o id, a data,  o item, a quantidade, o user e o conjunto de movimentos de stocks
	
    @Id @GeneratedValue
    private Long id;
    private LocalDateTime creationDate;
	
    @ManyToOne
    private Item item;
    private int quantity;
    private int completeQuantity;
    private boolean completed;
    private User user;
	
    @ManyToMany
    private Set<StockMovement> stockMovements = new HashSet<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDateTime getCreationDate() { return creationDate; }
    public void setCreationDate(LocalDateTime creationDate) { this.creationDate = creationDate; }
    public Item getItem() { return item; }
    public void setItem(Item item) { this.item = item; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getCompleteQuantity() { return completeQuantity; }
    public void setCompleteQuantity(int completeQuantity) { this.completeQuantity = completeQuantity; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public Set<StockMovement> getStockMovements() { return stockMovements; }
    public void setStockMovements(Set<StockMovement> stockMovements) { this.stockMovements = stockMovements; }
}