package com.example.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
public class StockMovement {

    //entidade de movimento de stock que vai conter o id, a data, o item, a quantidade e o conjunto de ordens
	
    @Id @GeneratedValue
    private Long id;
    private LocalDateTime creationDate;
	
    @ManyToOne
    private Item item;
    private int quantity;
	
    @ManyToMany(mappedBy = "stockMovements")
    private Set<Order> orders = new HashSet<>();
	
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDateTime getCreationDate() { return creationDate; }
    public void setCreationDate(LocalDateTime creationDate) { this.creationDate = creationDate; }
    public Item getItem() { return item; }
    public void setItem(Item item) { this.item = item; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public Set<Order> getOrders() { return orders; }
    public void setOrders(Set<Order> orders) { this.orders = orders; }
}